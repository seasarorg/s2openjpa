
Thank you for downloading this release of OpenJPA. For
documentation and project information, please see:

  http://openjpa.apache.org

