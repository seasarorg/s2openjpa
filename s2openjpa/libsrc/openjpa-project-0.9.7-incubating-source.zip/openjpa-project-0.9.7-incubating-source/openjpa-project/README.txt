
Thank you for downloading this incubator release of OpenJPA. For
documentation and project information, please see:

  http://incubator.apache.org/openjpa/

